const plans = {
  reset: {
    low: [
      ["Arrive", "Find a quiet spot and put your phone face-down.", "◎"],
      ["Breathe", "Try slow box breathing and let your shoulders drop.", "◇"],
      ["Reset", "Take a short, screen-free walk or stretch.", "↝"]
    ],
    steady: [
      ["Settle", "Grab water and choose a low-traffic place to pause.", "◎"],
      ["Move", "Walk one easy loop without checking notifications.", "↝"],
      ["Land", "Write one sentence about what matters next.", "◇"]
    ],
    high: [
      ["Move", "Take a brisk lap or climb a few flights of stairs.", "↝"],
      ["Refuel", "Get water and a snack if you need one.", "◎"],
      ["Center", "Sit, breathe, and choose your next priority.", "◇"]
    ]
  },
  study: {
    low: [
      ["Set up", "Open one class and choose the smallest useful task.", "◎"],
      ["Review", "Read notes or flashcards—no new hard material.", "◇"],
      ["Capture", "Write the next question to solve later.", "↗"]
    ],
    steady: [
      ["Choose", "Pick one concrete outcome for this study block.", "◎"],
      ["Focus", "Work on that one thing with notifications off.", "◇"],
      ["Close", "Write a one-line summary and your next step.", "↗"]
    ],
    high: [
      ["Aim", "Choose the hardest small problem you can finish now.", "◎"],
      ["Sprint", "Work fast on one assignment or practice set.", "◇"],
      ["Check", "Review your answer and note any loose ends.", "↗"]
    ]
  },
  admin: {
    low: [
      ["Scan", "Check your calendar for the next two days.", "◎"],
      ["Clear", "Answer one easy message or email.", "◇"],
      ["List", "Write tomorrow’s top three—not the whole backlog.", "↗"]
    ],
    steady: [
      ["Triage", "Choose one overdue or time-sensitive loose end.", "◎"],
      ["Handle", "Send, schedule, submit, or book that one thing.", "◇"],
      ["Preview", "Check tomorrow’s calendar and pack-list.", "↗"]
    ],
    high: [
      ["Sweep", "Collect small tasks that take under five minutes.", "◎"],
      ["Batch", "Complete as many as you can without switching apps.", "◇"],
      ["Reset", "Clean your downloads or backpack for a fresh start.", "↗"]
    ]
  }
};

const labels = {
  reset: "reset",
  study: "study",
  admin: "life-admin",
  low: "gentle",
  steady: "calm",
  high: "high-energy"
};

const gapForm = document.querySelector("#gapForm");
const planSection = document.querySelector("#planSection");
const planTitle = document.querySelector("#plan-title");
const taskList = document.querySelector("#taskList");
const timerDisplay = document.querySelector("#timerDisplay");
const timerBar = document.querySelector("#timerBar");
const timerButton = document.querySelector("#timerButton");
const resetButton = document.querySelector("#resetButton");
const completeButton = document.querySelector("#completeButton");
const streakCount = document.querySelector("#streakCount");
const toast = document.querySelector("#toast");

let totalSeconds = 30 * 60;
let remainingSeconds = totalSeconds;
let timerId = null;
let currentPlanKey = "30-steady-study";

function getSavedCount() {
  return Number(localStorage.getItem("gapcraft-count") || 0);
}

function setSavedCount(value) {
  localStorage.setItem("gapcraft-count", String(value));
  streakCount.textContent = value;
}

function allocateMinutes(total) {
  const usable = Math.max(total - 2, 3);
  const first = Math.max(2, Math.round(usable * 0.18));
  const third = Math.max(2, Math.round(usable * 0.2));
  const second = usable - first - third;
  return [first, second, third];
}

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const secs = (seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${secs}`;
}

function updateTimerUI() {
  timerDisplay.textContent = formatTime(remainingSeconds);
  const progress = ((totalSeconds - remainingSeconds) / totalSeconds) * 100;
  timerBar.style.width = `${progress}%`;
  document.title = timerId ? `${formatTime(remainingSeconds)} — GapCraft` : "GapCraft — Make the in-between count";
}

function stopTimer() {
  window.clearInterval(timerId);
  timerId = null;
  timerButton.textContent = "Start timer";
  timerButton.classList.remove("is-running");
}

function resetTimer() {
  stopTimer();
  remainingSeconds = totalSeconds;
  updateTimerUI();
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timeout);
  showToast.timeout = window.setTimeout(() => toast.classList.remove("show"), 2600);
}

function renderPlan(minutes, energy, goal) {
  const tasks = plans[goal][energy];
  const times = allocateMinutes(minutes);

  planTitle.textContent = `A ${labels[energy]} ${minutes}-minute ${labels[goal]} gap`;
  taskList.innerHTML = tasks.map((task, index) => `
    <li class="task-item">
      <span class="task-time">${times[index]} MIN</span>
      <div>
        <h3>${task[0]}</h3>
        <p>${task[1]}</p>
      </div>
      <span class="task-icon" aria-hidden="true">${task[2]}</span>
    </li>
  `).join("");

  totalSeconds = minutes * 60;
  remainingSeconds = totalSeconds;
  currentPlanKey = `${minutes}-${energy}-${goal}`;
  completeButton.disabled = false;
  completeButton.innerHTML = '<span aria-hidden="true">✓</span> Mark this gap complete';
  resetTimer();
}

gapForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const formData = new FormData(gapForm);
  renderPlan(Number(formData.get("minutes")), formData.get("energy"), formData.get("goal"));
  planSection.scrollIntoView({ behavior: "smooth", block: "start" });
});

timerButton.addEventListener("click", () => {
  if (timerId) {
    stopTimer();
    timerButton.textContent = "Resume timer";
    return;
  }

  if (remainingSeconds === 0) remainingSeconds = totalSeconds;
  timerButton.textContent = "Pause timer";
  timerButton.classList.add("is-running");
  timerId = window.setInterval(() => {
    remainingSeconds -= 1;
    updateTimerUI();
    if (remainingSeconds <= 0) {
      remainingSeconds = 0;
      stopTimer();
      updateTimerUI();
      showToast("Gap complete. Nice work—time to head out!");
    }
  }, 1000);
});

resetButton.addEventListener("click", resetTimer);

completeButton.addEventListener("click", () => {
  const lastCompleted = sessionStorage.getItem("gapcraft-last-completed");
  if (lastCompleted === currentPlanKey) {
    showToast("This gap is already in your count.");
    return;
  }

  const nextCount = getSavedCount() + 1;
  setSavedCount(nextCount);
  sessionStorage.setItem("gapcraft-last-completed", currentPlanKey);
  completeButton.disabled = true;
  completeButton.innerHTML = '<span aria-hidden="true">✓</span> Gap completed';
  showToast(`Win banked—${nextCount} gap${nextCount === 1 ? "" : "s"} crafted!`);
});

streakCount.textContent = getSavedCount();
renderPlan(30, "steady", "study");
